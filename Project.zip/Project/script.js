window.addEventListener('load', () => {
    const welcomeBlock = document.getElementById('welcome');
    const header = document.querySelector('header');
    const nav = document.querySelector('nav');

    // Показываем приветственный блок
    setTimeout(() => {
        welcomeBlock.classList.add('active');
        nav.classList.add('shifted'); // Сдвигаем nav вниз
    }, 500); // Задержка в 0.5 секунды

    // Скрываем приветственный блок через 3 секунды
    setTimeout(() => {
        welcomeBlock.classList.remove('active');
        welcomeBlock.classList.add('hidden'); // Добавляем класс hidden для скрытия
        header.classList.add('shifted'); // Убираем отступ у хедера
        nav.classList.remove('shifted'); // Убираем отступ у nav, возвращаем его на место
    }, 3500);
});
