// games.js
// Создаем объект для игры "Угадай число"
const numberGame = {
    targetNumber: Math.floor(Math.random() * 10) + 1,
    attempts: 0,
    
    init() {
        const gameContainer = document.querySelector('#number-game');
        const buttonsContainer = document.createElement('div');
        buttonsContainer.className = 'number-buttons';
        
        // Создаем кнопки с числами
        for (let i = 1; i <= 10; i++) {
            const button = document.createElement('button');
            button.textContent = i;
            button.onclick = () => this.makeGuess(i);
            buttonsContainer.appendChild(button);
        }
        
        gameContainer.appendChild(buttonsContainer);
        
        // Добавляем элемент для сообщений
        this.messageElement = document.createElement('p');
        this.messageElement.className = 'game-message';
        gameContainer.appendChild(this.messageElement);
    },
    
    makeGuess(number) {
        this.attempts++;
        if (number === this.targetNumber) {
            this.messageElement.textContent = `Поздравляем! Вы угадали число за ${this.attempts} попыток!`;
            this.messageElement.className = 'game-message success';
            // Добавляем кнопку "Играть снова"
            const resetButton = document.createElement('button');
            resetButton.textContent = 'Играть снова';
            resetButton.onclick = () => this.reset();
            this.messageElement.appendChild(resetButton);
        } else {
            const hint = number < this.targetNumber ? 'больше' : 'меньше';
            this.messageElement.textContent = `Загаданное число ${hint}. Попытка ${this.attempts}`;
            this.messageElement.className = 'game-message';
        }
    },
    
    reset() {
        this.targetNumber = Math.floor(Math.random() * 10) + 1;
        this.attempts = 0;
        this.messageElement.textContent = '';
        this.messageElement.className = 'game-message';
    }
};

// Объект для игры "Камень, ножницы, бумага"
const rpsGame = {
    init() {
        const gameContainer = document.querySelector('#rps-game');
        const choices = ['камень', 'ножницы', 'бумага'];
        
        const buttonsContainer = document.createElement('div');
        buttonsContainer.className = 'rps-buttons';
        
        choices.forEach(choice => {
            const button = document.createElement('button');
            button.textContent = choice;
            button.onclick = () => this.play(choice);
            buttonsContainer.appendChild(button);
        });
        
        gameContainer.appendChild(buttonsContainer);
        
        // Добавляем элемент для результатов
        this.resultElement = document.createElement('div');
        this.resultElement.className = 'game-result';
        gameContainer.appendChild(this.resultElement);
    },
    
    play(playerChoice) {
        const choices = ['камень', 'ножницы', 'бумага'];
        const computerChoice = choices[Math.floor(Math.random() * 3)];
        
        let result;
        if (playerChoice === computerChoice) {
            result = 'Ничья!';
        } else if (
            (playerChoice === 'камень' && computerChoice === 'ножницы') ||
            (playerChoice === 'ножницы' && computerChoice === 'бумага') ||
            (playerChoice === 'бумага' && computerChoice === 'камень')
        ) {
            result = 'Вы победили!';
        } else {
            result = 'Компьютер победил!';
        }
        
        this.resultElement.innerHTML = `
            <p>Ваш выбор: ${playerChoice}</p>
            <p>Выбор компьютера: ${computerChoice}</p>
            <p class="result-message ${result === 'Вы победили!' ? 'success' : ''}">${result}</p>
        `;
    }
};